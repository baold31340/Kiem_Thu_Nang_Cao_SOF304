package SOF304_ASM1;

import org.junit.runner.RunWith;
import org.junit.runners.*;

@RunWith(Suite.class)
@Suite.SuiteClasses(

{KhoaHocTest.class, ChuyenDeTest.class, NguoiHocTest.class, HocVienTest.class, NhanVienTest.class}
)
public class TestSuite{ // nothing
}
