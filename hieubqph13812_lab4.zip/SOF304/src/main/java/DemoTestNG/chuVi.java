package DemoTestNG;

public class chuVi {
public static int tinhChuVi(int a, int b) {
	return (a+b)*2;
}
}
