package SOF304.Lab2.Class;

public class PhuongTrinhBacHai {
	public double x1;
	public double x2;
}
