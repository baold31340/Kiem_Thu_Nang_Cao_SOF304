package SOF304.Lab1;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses(

{Lab1_3Test.class, CalulatorTest.class}
)
public class TestSuite{ // nothing
}
