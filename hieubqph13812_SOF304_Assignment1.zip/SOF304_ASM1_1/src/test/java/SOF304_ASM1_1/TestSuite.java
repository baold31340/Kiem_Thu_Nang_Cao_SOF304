package SOF304_ASM1_1;

import org.junit.runner.RunWith;
import org.junit.runners.*;

@RunWith(Suite.class)
@Suite.SuiteClasses(

{ KhoaHocTest.class, KhoaHocTestGiaTriBien.class, KhoaHocTestNgoaiLe.class})
public class TestSuite { // nothing
}
