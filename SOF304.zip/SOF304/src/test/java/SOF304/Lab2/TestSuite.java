package SOF304.Lab2;

import org.junit.runner.RunWith;
import org.junit.runners.*;

@RunWith(Suite.class)
@Suite.SuiteClasses(

{ giaiThuaTest.class })
public class TestSuite { // nothing
}
