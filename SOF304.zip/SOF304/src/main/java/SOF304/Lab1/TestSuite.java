package SOF304.Lab1;

import org.junit.runner.RunWith;
import org.junit.runners.*;


@RunWith(Suite.class)
@Suite.SuiteClasses(

{ CalulatorTest.class })
public class TestSuite { // nothing
}
