package SOF304.Lab1;

public class Lab1_3 {

	public boolean isEventNumber(int input) {
		if (input % 2 == 0) {
			return true;
		} else
			return false;

	}
	
	public boolean soLe(int input) {
		if (input % 2 == 1) {
			return true;
		} else
			return false;

	}

	public Lab1_3() {
		// TODO Auto-generated constructor stub
	}

}
