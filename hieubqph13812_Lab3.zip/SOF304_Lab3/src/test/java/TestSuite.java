import org.junit.runner.RunWith;
import org.junit.runners.*;

@RunWith(Suite.class)
@Suite.SuiteClasses(

{ErrorCollectorExampleTest.class, PersonTest.class, TinhGiaiThuaTest.class, JUnitMessageTest.class, ParmaterGiaiThuaTest.class}
)
public class TestSuite{ // nothing
}